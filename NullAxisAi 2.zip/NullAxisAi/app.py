from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from enum import Enum
import json
import os
from datetime import datetime

class Classification(str, Enum):
    TECHNICAL_SUPPORT = "technical_support"
    FEATURE_REQUEST = "feature_request"
    SALES_LEAD = "sales_lead"
    UNKNOWN = "unknown"

class InquiryRequest(BaseModel):
    message: str

class InquiryResponse(BaseModel):
    response: str
    classification: Classification
    needs_escalation: bool
    knowledge_found: bool = False

app = FastAPI(title="Customer Service Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock knowledge base
KNOWLEDGE_BASE = {
    "login": "To reset your password, click on the 'Forgot Password' link on the login page and follow the instructions sent to your email.",
    "account": "You can manage your account settings, including profile information and preferences, in the Account Settings dashboard.",
    "billing": "For billing inquiries, please visit the Billing section in your dashboard. We accept all major credit cards and offer monthly/annual plans.",
    "api": "Our API documentation is available at docs.nullaxis.ai/api. You'll need to generate an API key from your dashboard.",
    "integration": "We support integrations with popular platforms like Slack, Teams, and Jira. Visit our Integration Hub to get started.",
    "security": "We use industry-standard encryption and comply with SOC 2 and GDPR requirements. Two-factor authentication is available.",
}

NEGATIVE_WORDS = ["angry", "upset", "disappointed", "frustrated", "terrible", "awful", 
                 "horrible", "bad", "worst", "unhappy", "hate", "useless"]

FEATURE_REQUESTS_DIR = "feature_requests"
os.makedirs(FEATURE_REQUESTS_DIR, exist_ok=True)

def classify_inquiry(message: str) -> Classification:
    message = message.lower()
    
    tech_keywords = ["help", "issue", "problem", "error", "doesn't work", "broken", "fix", 
                    "login", "password", "account", "install", "setup", "configure"]
    
    feature_keywords = ["feature", "add", "improve", "enhancement", "suggestion", "implement",
                       "would be nice", "should have", "could you add", "missing"]
    
    sales_keywords = ["price", "cost", "quote", "demo", "trial", "purchase", "subscription", 
                     "pricing", "enterprise", "license", "plan", "upgrade"]
    
    tech_count = sum(1 for keyword in tech_keywords if keyword in message)
    feature_count = sum(1 for keyword in feature_keywords if keyword in message)
    sales_count = sum(1 for keyword in sales_keywords if keyword in message)
    
    counts = {
        Classification.TECHNICAL_SUPPORT: tech_count,
        Classification.FEATURE_REQUEST: feature_count,
        Classification.SALES_LEAD: sales_count
    }
    
    if max(counts.values()) > 0:
        return max(counts.items(), key=lambda x: x[1])[0]
    return Classification.UNKNOWN

def search_knowledge_base(inquiry: str) -> tuple[str, bool]:
    inquiry = inquiry.lower()
    
    for key, value in KNOWLEDGE_BASE.items():
        if key in inquiry:
            return value, True
    
    return "", False

def log_feature_request(message: str) -> None:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{FEATURE_REQUESTS_DIR}/feature_request_{timestamp}.json"
    
    with open(filename, 'w') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "request": message
        }, f, indent=2)

def needs_escalation(classification: Classification, knowledge_found: bool, message: str) -> bool:
    if classification == Classification.UNKNOWN:
        return True
    
    if classification == Classification.TECHNICAL_SUPPORT and not knowledge_found:
        return True
    
    message_lower = message.lower()
    if any(word in message_lower for word in NEGATIVE_WORDS):
        return True
    
    urgent_words = ["urgent", "immediately", "asap", "emergency", "critical"]
    if any(word in message_lower for word in urgent_words):
        return True
    
    return False

def generate_response(classification: Classification, message: str) -> tuple[str, bool]:
    if classification == Classification.TECHNICAL_SUPPORT:
        kb_info, knowledge_found = search_knowledge_base(message)
        
        if knowledge_found:
            return f"Thanks for reaching out! {kb_info} Is there anything else you need help with?", knowledge_found
        else:
            return "I understand you're having a technical issue. I'll route this to our support team right away. They'll get back to you shortly with a solution.", knowledge_found
    
    elif classification == Classification.FEATURE_REQUEST:
        log_feature_request(message)
        return "Thank you for your suggestion! We've logged your feature request for our product team to review. We're always looking to improve our product based on customer feedback.", False
    
    elif classification == Classification.SALES_LEAD:
        return "Thanks for your interest in NullAxis.ai! To better assist you, could you please share:\n\n1. Your company name\n2. Team size\n3. Primary use case\n\nOur sales team will reach out with detailed pricing and demo options.", False
    
    else:
        return "I'm not quite sure what you're asking about. Could you please provide more details about your inquiry? This will help me direct you to the right team.", False

@app.post("/api/inquiry", response_model=InquiryResponse)
async def process_inquiry(request: InquiryRequest):
    message = request.message
    
    classification = classify_inquiry(message)
    response, knowledge_found = generate_response(classification, message)
    escalation_needed = needs_escalation(classification, knowledge_found, message)
    
    return {
        "response": response,
        "classification": classification,
        "needs_escalation": escalation_needed,
        "knowledge_found": knowledge_found if classification == Classification.TECHNICAL_SUPPORT else False
    }

@app.get("/api/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)