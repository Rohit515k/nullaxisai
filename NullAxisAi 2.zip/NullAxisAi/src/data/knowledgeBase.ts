import { KnowledgeBaseEntry } from '../types';

const knowledgeBase: KnowledgeBaseEntry[] = [
  {
    id: 'kb-001',
    topic: 'Reset Password',
    keywords: ['reset', 'password', 'forgot', 'login', 'sign in', 'access'],
    content: 'To reset your password, please go to the login page and click on the "Forgot Password" link. You will receive an email with instructions to create a new password. The link in the email expires after 24 hours.'
  },
  {
    id: 'kb-002',
    topic: 'App Installation',
    keywords: ['install', 'download', 'app', 'application', 'setup', 'mobile'],
    content: 'Our app is available on both iOS and Android platforms. For iOS, visit the App Store and search for "NullAxis". For Android, visit the Google Play Store and search for "NullAxis". After downloading, follow the on-screen instructions to complete the installation.'
  },
  {
    id: 'kb-003',
    topic: 'Connectivity Issues',
    keywords: ['connection', 'connectivity', 'offline', 'network', 'internet', 'connect'],
    content: 'If you\'re experiencing connectivity issues, please check your internet connection first. Ensure your Wi-Fi or cellular data is turned on and working. If the problem persists, try restarting the app or your device. You might also want to check if your firewall or network settings are blocking our service.'
  },
  {
    id: 'kb-004',
    topic: 'Data Synchronization',
    keywords: ['sync', 'synchronization', 'data', 'backup', 'cloud', 'update'],
    content: 'Data synchronization happens automatically when you\'re connected to the internet. If your data isn\'t syncing, ensure you have a stable internet connection. You can manually trigger a sync by pulling down on the main screen to refresh. If issues persist, go to Settings > Account > Sync Now.'
  },
  {
    id: 'kb-005',
    topic: 'Integration with Third-Party Services',
    keywords: ['integration', 'connect', 'third-party', 'service', 'API', 'slack', 'zapier'],
    content: 'To integrate with third-party services, go to Settings > Integrations and select the service you want to connect. Follow the authentication process to grant permissions. For advanced integrations requiring API access, visit our developer portal at developer.nullaxis.ai for API documentation.'
  },
  {
    id: 'kb-006',
    topic: 'Billing and Subscription',
    keywords: ['billing', 'subscription', 'payment', 'invoice', 'charge', 'plan', 'upgrade'],
    content: 'You can manage your subscription from the account dashboard. Go to Settings > Billing to view your current plan, payment history, and to update your payment method. If you want to upgrade or downgrade your plan, click on "Change Plan" and select your preferred option.'
  }
];

export default knowledgeBase;