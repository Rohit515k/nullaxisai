import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ChatWindow from './components/ChatWindow';

function App() {
  return (
    <div className="flex flex-col min-h-screen bg-dark-primary text-dark-text-primary">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-6xl w-full mx-auto p-4 sm:p-6 my-4">
        <div className="bg-dark-secondary rounded-lg shadow-xl flex-1 flex flex-col overflow-hidden border border-gray-800 backdrop-blur-sm bg-opacity-50">
          <div className="bg-[#1C1C3C] bg-opacity-50 p-4 border-b border-gray-800">
            <h2 className="text-lg font-medium text-dark-text-primary">Customer Support</h2>
            <p className="text-sm text-dark-text-secondary">Ask a question or report an issue</p>
          </div>
          
          <div className="flex-1 flex flex-col overflow-hidden">
            <ChatWindow />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App