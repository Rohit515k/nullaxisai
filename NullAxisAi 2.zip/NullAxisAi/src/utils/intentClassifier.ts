import { Intent, IntentType } from '../types';

// Simple keyword-based intent classifier
export function classifyIntent(query: string): Intent {
  const lowerQuery = query.toLowerCase();
  
  // Technical support keywords
  const technicalKeywords = [
    'help', 'problem', 'issue', 'error', 'bug', 'fix', 'broken', 
    'not working', 'password', 'reset', 'login', 'connect', 'install',
    'download', 'update', 'sync', 'data', 'lost', 'missing', 'crash'
  ];
  
  // Feature request keywords
  const featureKeywords = [
    'feature', 'add', 'suggestion', 'improve', 'enhancement', 'new', 
    'functionality', 'implement', 'request', 'would be nice', 'should have',
    'missing feature', 'better if', 'integration', 'dark mode', 'interface'
  ];
  
  // Sales keywords
  const salesKeywords = [
    'price', 'cost', 'purchase', 'buy', 'plan', 'subscription', 'demo', 
    'trial', 'enterprise', 'license', 'pricing', 'quote', 'business', 
    'company', 'team', 'discount', 'offer', 'package', 'interested in'
  ];

  // Count keyword matches for each intent
  const technicalScore = countKeywordMatches(lowerQuery, technicalKeywords);
  const featureScore = countKeywordMatches(lowerQuery, featureKeywords);
  const salesScore = countKeywordMatches(lowerQuery, salesKeywords);
  
  // Determine the intent with the highest score
  const scores = [
    { type: 'technical_support' as IntentType, score: technicalScore },
    { type: 'feature_request' as IntentType, score: featureScore },
    { type: 'sales_lead' as IntentType, score: salesScore }
  ];
  
  // Sort by score in descending order
  scores.sort((a, b) => b.score - a.score);
  
  // If the highest score is 0, return unknown intent
  if (scores[0].score === 0) {
    return {
      type: 'unknown',
      confidence: 0
    };
  }
  
  // Calculate confidence as a ratio of highest score to total score
  const totalScore = technicalScore + featureScore + salesScore;
  const confidence = scores[0].score / totalScore;
  
  return {
    type: scores[0].type,
    confidence: confidence
  };
}

// Helper function to count keyword matches
function countKeywordMatches(text: string, keywords: string[]): number {
  return keywords.reduce((count, keyword) => {
    return text.includes(keyword) ? count + 1 : count;
  }, 0);
}

// Detect negative sentiment for potential escalation
export function detectNegativeSentiment(text: string): boolean {
  const negativeKeywords = [
    'terrible', 'awful', 'horrible', 'bad', 'worst', 'poor', 'disappointed',
    'frustrated', 'annoyed', 'angry', 'upset', 'doesn\'t work', 'not working',
    'useless', 'waste', 'refund', 'cancel', 'stop working', 'broken',
    'hate', 'disaster', 'failure', 'garbage', 'terrible experience',
    'nothing works', 'very frustrated', 'speak to a human', 'real person',
    'unacceptable', 'disappointed', 'ridiculous', 'stupid'
  ];
  
  const lowerText = text.toLowerCase();
  return negativeKeywords.some(keyword => lowerText.includes(keyword));
}

// Detect if a query needs human escalation
export function needsHumanEscalation(query: string, intent: Intent): boolean {
  // Check for direct request for human
  if (query.toLowerCase().includes('human') || 
      query.toLowerCase().includes('agent') ||
      query.toLowerCase().includes('person') ||
      query.toLowerCase().includes('representative') ||
      query.toLowerCase().includes('speak to someone')) {
    return true;
  }
  
  // Check for negative sentiment
  if (detectNegativeSentiment(query)) {
    return true;
  }
  
  // Check for very low confidence in intent classification
  if (intent.confidence < 0.3) {
    return true;
  }
  
  // Check for very complex queries (approximated by length)
  if (query.length > 200) {
    return true;
  }
  
  return false;
}