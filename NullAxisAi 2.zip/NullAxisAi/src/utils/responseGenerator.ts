import { Message, MessageOption, Intent, IntentType } from '../types';
import { searchKnowledgeBase } from './knowledgeBaseSearch';
import { needsHumanEscalation } from './intentClassifier';

// Generate UUID for message IDs
function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Generate appropriate response based on intent
export function generateResponse(query: string, intent: Intent): Message {
  // Check if escalation is needed
  if (needsHumanEscalation(query, intent)) {
    return createEscalationMessage();
  }

  // Generate response based on intent type
  switch (intent.type) {
    case 'technical_support':
      return generateTechnicalSupportResponse(query);
    case 'feature_request':
      return generateFeatureRequestResponse();
    case 'sales_lead':
      return generateSalesLeadResponse();
    default:
      return generateUnknownIntentResponse();
  }
}

// Generate response for technical support queries
function generateTechnicalSupportResponse(query: string): Message {
  // Search knowledge base for relevant information
  const kbEntry = searchKnowledgeBase(query);
  
  if (kbEntry) {
    // Knowledge base entry found
    return {
      id: generateId(),
      role: 'agent',
      content: `Thanks for reaching out! Regarding your ${kbEntry.topic.toLowerCase()}, here's some information:\n\n${kbEntry.content}\n\nDoes this resolve your issue?`,
      timestamp: new Date(),
      options: [
        { id: generateId(), label: 'Yes, thank you!', value: 'resolved' },
        { id: generateId(), label: 'No, I need more help', value: 'escalate' }
      ]
    };
  } else {
    // No knowledge base entry found
    return {
      id: generateId(),
      role: 'agent',
      content: `Thanks for your query. I couldn't find an immediate answer, but I've routed your request to our technical support team. They will get back to you shortly.`,
      timestamp: new Date(),
      options: [
        { id: generateId(), label: 'Ask another question', value: 'new_question' }
      ]
    };
  }
}

// Generate initial response for feature request
function generateFeatureRequestResponse(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: 'What improvement or feature would you like to see added?',
    timestamp: new Date(),
    options: [
      { id: generateId(), label: 'UI Enhancement (e.g., Dark Mode)', value: 'ui_enhancement' },
      { id: generateId(), label: 'New Integration', value: 'integration' },
      { id: generateId(), label: 'Performance Upgrade', value: 'performance' },
      { id: generateId(), label: 'Security Enhancement', value: 'security' },
      { id: generateId(), label: 'Smart Suggestions', value: 'ai_feature' },
      { id: generateId(), label: 'Something else (type below)', value: 'custom' }
    ]
  };
}

// Generate response after feature request selection
export function generateFeatureRequestConfirmation(feature: string): Message {
  // Log the feature request (in a real app, this would save to a database)
  console.log('Feature request logged:', feature);
  
  return {
    id: generateId(),
    role: 'agent',
    content: `Thank you for your suggestion! We've logged your feature request for "${feature}" for our product team to review. We appreciate your feedback!`,
    timestamp: new Date(),
    options: [
      { id: generateId(), label: 'Submit another request', value: 'new_request' },
      { id: generateId(), label: 'Ask about something else', value: 'new_topic' }
    ]
  };
}

// Generate initial response for sales lead
function generateSalesLeadResponse(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: "Thanks for your interest in NullAxis! I'd like to gather some information to better assist you. What's your company name?",
    timestamp: new Date()
  };
}

// Generate follow-up questions for sales lead
export function generateSalesLeadFollowUp(step: number, previousAnswer?: string): Message {
  switch (step) {
    case 1: // After company name
      return {
        id: generateId(),
        role: 'agent',
        content: `Thanks! How many team members do you have at ${previousAnswer}?`,
        timestamp: new Date(),
        options: [
          { id: generateId(), label: '1-10', value: '1-10' },
          { id: generateId(), label: '11-50', value: '11-50' },
          { id: generateId(), label: '51-200', value: '51-200' },
          { id: generateId(), label: '201+', value: '201+' }
        ]
      };
    case 2: // After team size
      return {
        id: generateId(),
        role: 'agent',
        content: 'Which product are you interested in?',
        timestamp: new Date(),
        options: [
          { id: generateId(), label: 'Live Chat', value: 'live_chat' },
          { id: generateId(), label: 'AI Assistant', value: 'ai_assistant' },
          { id: generateId(), label: 'Analytics Dashboard', value: 'analytics' },
          { id: generateId(), label: 'All of the Above', value: 'all' }
        ]
      };
    case 3: // After product interest
      return {
        id: generateId(),
        role: 'agent',
        content: 'Would you like to schedule a call with our sales team?',
        timestamp: new Date(),
        options: [
          { id: generateId(), label: 'Yes', value: 'yes' },
          { id: generateId(), label: 'No', value: 'no' }
        ]
      };
    case 4: // Final confirmation
      return {
        id: generateId(),
        role: 'agent',
        content: `Thank you for your interest! Our sales team will be in touch soon. In the meantime, could you tell us more about your specific needs and how you're planning to use our product?`,
        timestamp: new Date()
      };
    default:
      return generateUnknownIntentResponse();
  }
}

// Generate response for unknown intent
function generateUnknownIntentResponse(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: "I'm not sure how to help with that yet. I've forwarded your message to our team. In the meantime, can I assist you with technical support, a feature request, or information about our products?",
    timestamp: new Date(),
    options: [
      { id: generateId(), label: 'Technical Support', value: 'technical_support' },
      { id: generateId(), label: 'Feature Request', value: 'feature_request' },
      { id: generateId(), label: 'Product Information', value: 'sales_lead' }
    ]
  };
}

// Generate response for escalation to human
function createEscalationMessage(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: "I understand this is important. I'm connecting you with a human agent who will be with you shortly. Thank you for your patience.",
    timestamp: new Date()
  };
}

// Generate initial greeting message
export function generateGreeting(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: "Hi there! I'm the NullAxis.ai virtual assistant. How can I help you today?",
    timestamp: new Date(),
    options: [
      { id: generateId(), label: 'Technical Support', value: 'technical_support' },
      { id: generateId(), label: 'Feature Request', value: 'feature_request' },
      { id: generateId(), label: 'Sales Inquiry', value: 'sales_lead' }
    ]
  };
}

// Generate typing indicator message
export function generateTypingIndicator(): Message {
  return {
    id: generateId(),
    role: 'agent',
    content: '',
    timestamp: new Date(),
    isTyping: true
  };
}