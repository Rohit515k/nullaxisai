import knowledgeBase from '../data/knowledgeBase';
import { KnowledgeBaseEntry } from '../types';

// Search the knowledge base for relevant entries based on a query
export function searchKnowledgeBase(query: string): KnowledgeBaseEntry | null {
  const lowerQuery = query.toLowerCase();
  
  // Score each entry based on keyword matches
  const scoredEntries = knowledgeBase.map(entry => {
    const keywordMatches = entry.keywords.reduce((count, keyword) => {
      return lowerQuery.includes(keyword.toLowerCase()) ? count + 1 : count;
    }, 0);
    
    // Also check if query contains the topic
    const topicMatch = lowerQuery.includes(entry.topic.toLowerCase()) ? 3 : 0;
    
    return {
      entry,
      score: keywordMatches + topicMatch
    };
  });
  
  // Sort by score in descending order
  scoredEntries.sort((a, b) => b.score - a.score);
  
  // Return the highest scoring entry if it has at least some relevance
  if (scoredEntries.length > 0 && scoredEntries[0].score > 0) {
    return scoredEntries[0].entry;
  }
  
  return null;
}