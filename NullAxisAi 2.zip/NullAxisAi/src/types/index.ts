export type MessageRole = 'user' | 'agent' | 'system';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  options?: MessageOption[];
  isTyping?: boolean;
}

export interface MessageOption {
  id: string;
  label: string;
  value: string;
}

export type IntentType = 'technical_support' | 'feature_request' | 'sales_lead' | 'unknown';

export interface Intent {
  type: IntentType;
  confidence: number;
  details?: Record<string, any>;
}

export interface TechnicalSupportRequest {
  intent: 'technical_support';
  issue: string;
  userId: string;
  timestamp: Date;
  resolved?: boolean;
  escalated?: boolean;
  knowledgeBaseEntryId?: string;
}

export interface FeatureRequest {
  intent: 'feature_request';
  feature: string;
  category: string;
  userId: string;
  timestamp: Date;
  details?: string;
}

export interface SalesLead {
  intent: 'sales_lead';
  companyName: string;
  teamSize?: number;
  productInterest?: string;
  scheduleCall?: boolean;
  userId: string;
  timestamp: Date;
  details?: string;
}

export interface KnowledgeBaseEntry {
  id: string;
  topic: string;
  keywords: string[];
  content: string;
}