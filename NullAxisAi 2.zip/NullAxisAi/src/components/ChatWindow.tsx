import React, { useState, useEffect, useRef } from 'react';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import { Message, MessageOption, Intent, IntentType } from '../types';
import { classifyIntent } from '../utils/intentClassifier';
import { 
  generateResponse, 
  generateGreeting, 
  generateTypingIndicator,
  generateFeatureRequestConfirmation,
  generateSalesLeadFollowUp
} from '../utils/responseGenerator';

const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentIntent, setCurrentIntent] = useState<Intent | null>(null);
  const [salesLeadStep, setSalesLeadStep] = useState(0);
  const [salesLeadData, setSalesLeadData] = useState<Record<string, string>>({});
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([generateGreeting()]);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const simulateTyping = async () => {
    setLoading(true);
    setMessages(prev => [...prev, generateTypingIndicator()]);
    const typingDelay = Math.random() * 1000 + 500;
    await new Promise(resolve => setTimeout(resolve, typingDelay));
    setMessages(prev => prev.filter(msg => !msg.isTyping));
    setLoading(false);
    return true;
  };

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    const userMessage: Message = {
      id: Math.random().toString(36).substring(2, 15),
      role: 'user',
      content,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    await simulateTyping();
    
    if (currentIntent?.type === 'sales_lead' && salesLeadStep > 0) {
      handleSalesLeadProgress(content);
    } else {
      const intent = classifyIntent(content);
      setCurrentIntent(intent);
      const responseMessage = generateResponse(content, intent);
      setMessages(prev => [...prev, responseMessage]);
      
      if (intent.type === 'sales_lead') {
        setSalesLeadStep(1);
      }
    }
  };

  const handleOptionSelect = async (option: MessageOption) => {
    const userMessage: Message = {
      id: Math.random().toString(36).substring(2, 15),
      role: 'user',
      content: option.label,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    await simulateTyping();
    
    if (option.value === 'technical_support' || option.value === 'feature_request' || option.value === 'sales_lead') {
      const newIntent: Intent = {
        type: option.value as IntentType,
        confidence: 1.0
      };
      setCurrentIntent(newIntent);
      const responseMessage = generateResponse('', newIntent);
      setMessages(prev => [...prev, responseMessage]);
      
      if (option.value === 'sales_lead') {
        setSalesLeadStep(1);
      }
    } else if (currentIntent?.type === 'feature_request' && 
              ['ui_enhancement', 'integration', 'performance', 'security', 'ai_feature'].includes(option.value)) {
      const confirmation = generateFeatureRequestConfirmation(option.label);
      setMessages(prev => [...prev, confirmation]);
    } else if (currentIntent?.type === 'sales_lead' && salesLeadStep > 0) {
      handleSalesLeadOptionSelection(option);
    } else if (option.value === 'escalate') {
      const escalationMessage: Message = {
        id: Math.random().toString(36).substring(2, 15),
        role: 'agent',
        content: "I'm connecting you with a human agent who will be with you shortly. Thank you for your patience.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, escalationMessage]);
    } else if (option.value === 'resolved' || option.value === 'new_question' || option.value === 'new_request' || option.value === 'new_topic') {
      setCurrentIntent(null);
      setSalesLeadStep(0);
      setSalesLeadData({});
      
      const newGreeting: Message = {
        id: Math.random().toString(36).substring(2, 15),
        role: 'agent',
        content: "Is there anything else I can help you with today?",
        timestamp: new Date(),
        options: [
          { id: Math.random().toString(36).substring(2, 15), label: 'Technical Support', value: 'technical_support' },
          { id: Math.random().toString(36).substring(2, 15), label: 'Feature Request', value: 'feature_request' },
          { id: Math.random().toString(36).substring(2, 15), label: 'Sales Inquiry', value: 'sales_lead' }
        ]
      };
      setMessages(prev => [...prev, newGreeting]);
    }
  };

  const handleSalesLeadProgress = (answer: string) => {
    const fieldNames = ['company', 'teamSize', 'productInterest', 'scheduleCall'];
    const currentField = fieldNames[salesLeadStep - 1];
    
    setSalesLeadData(prev => ({
      ...prev,
      [currentField]: answer
    }));
    
    const nextMessage = generateSalesLeadFollowUp(salesLeadStep, answer);
    setMessages(prev => [...prev, nextMessage]);
    setSalesLeadStep(prev => prev + 1);
    
    if (salesLeadStep >= 4) {
      console.log('Sales Lead Data:', {
        ...salesLeadData,
        [currentField]: answer
      });
      setSalesLeadStep(0);
    }
  };

  const handleSalesLeadOptionSelection = (option: MessageOption) => {
    const fieldNames = ['company', 'teamSize', 'productInterest', 'scheduleCall'];
    const currentField = fieldNames[salesLeadStep - 1];
    
    setSalesLeadData(prev => ({
      ...prev,
      [currentField]: option.value
    }));
    
    const nextMessage = generateSalesLeadFollowUp(salesLeadStep, salesLeadData.company);
    setMessages(prev => [...prev, nextMessage]);
    setSalesLeadStep(prev => prev + 1);
    
    if (salesLeadStep >= 4) {
      console.log('Sales Lead Data:', {
        ...salesLeadData,
        [currentField]: option.value
      });
      setSalesLeadStep(0);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-dark-secondary scrollbar-track-transparent">
        <div className="flex flex-col items-center">
          {messages.map((message) => (
            <ChatMessage 
              key={message.id} 
              message={message} 
              onOptionSelect={handleOptionSelect}
            />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-800">
        <ChatInput 
          onSendMessage={handleSendMessage} 
          isDisabled={loading}
          placeholder={
            currentIntent?.type === 'sales_lead' && salesLeadStep === 1
              ? "Enter your company name..."
              : "Type your message here..."
          }
        />
      </div>
    </div>
  );
};

export default ChatWindow;