import React from 'react';
import { MessageSquare, Bot, User } from 'lucide-react';
import classNames from 'classnames';
import { Message, MessageOption } from '../types';

interface ChatMessageProps {
  message: Message;
  onOptionSelect?: (option: MessageOption) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, onOptionSelect }) => {
  const isUser = message.role === 'user';
  
  return (
    <div 
      className={classNames(
        'flex w-full mb-4 max-w-4xl animate-fadeIn', 
        isUser ? 'justify-end' : 'justify-start'
      )}
    >
      <div 
        className={classNames(
          'flex gap-3 max-w-[85%]',
          isUser ? 'flex-row-reverse' : 'flex-row'
        )}
      >
        {/* Avatar */}
        <div 
          className={classNames(
            'flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center text-white shadow-lg',
            isUser ? 'bg-dark-accent' : 'bg-dark-secondary'
          )}
        >
          {isUser ? (
            <User size={20} />
          ) : (
            <Bot size={20} />
          )}
        </div>
        
        {/* Message Content */}
        <div className="flex flex-col">
          <div 
            className={classNames(
              'px-4 py-3 rounded-lg shadow-lg transition-all duration-200 hover:shadow-xl',
              isUser 
                ? 'bg-dark-accent bg-opacity-90 text-white rounded-tr-none' 
                : 'bg-dark-secondary bg-opacity-75 text-dark-text-primary rounded-tl-none'
            )}
          >
            {message.isTyping ? (
              <div className="flex space-x-2 py-2 px-1">
                <div className="w-2 h-2 bg-dark-text-secondary rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-dark-text-secondary rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 bg-dark-text-secondary rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            ) : (
              <div className="whitespace-pre-wrap">{message.content}</div>
            )}
          </div>
          
          {/* Options Buttons */}
          {message.options && message.options.length > 0 && !isUser && (
            <div className="flex flex-wrap gap-2 mt-2">
              {message.options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => onOptionSelect && onOptionSelect(option)}
                  className="px-3 py-2 bg-dark-secondary text-dark-accent border border-dark-accent rounded-md text-sm hover:bg-dark-accent hover:text-white transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  {option.label}
                </button>
              ))}
            </div>
          )}
          
          {/* Timestamp */}
          <div 
            className={classNames(
              'text-xs text-dark-text-secondary mt-1',
              isUser ? 'text-right' : 'text-left'
            )}
          >
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;