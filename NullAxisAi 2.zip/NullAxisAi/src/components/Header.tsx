import React from 'react';
import { Bot, MessageSquare, Settings } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-dark-secondary bg-opacity-75 backdrop-blur-sm text-dark-text-primary p-4 shadow-lg border-b border-gray-800">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bot size={28} className="text-dark-accent" />
          <h1 className="text-xl font-semibold">NullAxis.ai</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-md hover:bg-dark-primary transition-all duration-200">
            <MessageSquare size={18} />
            <span className="text-sm hidden sm:inline">Support</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-md hover:bg-dark-primary transition-all duration-200">
            <Settings size={18} />
            <span className="text-sm hidden sm:inline">Settings</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;