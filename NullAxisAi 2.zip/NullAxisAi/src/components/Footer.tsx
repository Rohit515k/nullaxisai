import React from 'react';
import { Github, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-secondary bg-opacity-75 backdrop-blur-sm text-dark-text-primary py-3 px-4 text-sm border-t border-gray-800">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center">
        <div className="mb-2 sm:mb-0">
          <p>© 2025 NullAxis.ai. All rights reserved.</p>
        </div>
        
        <div className="flex items-center gap-4">
          <a href="#" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">Privacy</a>
          <a href="#" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">Terms</a>
          <a href="#" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">Help</a>
          
          <div className="flex items-center gap-3 ml-2">
            <a href="#" aria-label="Github" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">
              <Github size={18} />
            </a>
            <a href="#" aria-label="Twitter" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">
              <Twitter size={18} />
            </a>
            <a href="#" aria-label="LinkedIn" className="text-dark-text-secondary hover:text-dark-text-primary transition-colors duration-200">
              <Linkedin size={18} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;