import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isDisabled?: boolean;
  placeholder?: string;
}

const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  isDisabled = false,
  placeholder = "Type your message here..."
}) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isDisabled) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <form 
      onSubmit={handleSubmit}
      className="flex items-center gap-2 bg-dark-secondary bg-opacity-75 p-3 rounded-lg shadow-lg border border-gray-800"
    >
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder={placeholder}
        disabled={isDisabled}
        className="flex-grow px-3 py-2 border-none focus:outline-none focus:ring-0 text-dark-text-primary placeholder-dark-text-secondary bg-transparent"
      />
      <button
        type="submit"
        disabled={isDisabled || !message.trim()}
        className="p-2 rounded-full bg-dark-accent text-white hover:bg-opacity-90 transition-all duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed shadow-md hover:shadow-lg"
      >
        <Send size={20} />
      </button>
    </form>
  );
};

export default ChatInput;